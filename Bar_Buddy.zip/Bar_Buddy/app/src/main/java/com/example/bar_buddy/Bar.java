package com.example.bar_buddy;

public class Bar {
    String text;

    Bar(String text) {
        this.text = text;
    }
}
